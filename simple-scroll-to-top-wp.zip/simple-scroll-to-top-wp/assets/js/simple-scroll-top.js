jQuery(document).ready(function($) {
    var btn = $('#sstt-scroll-top');

    // Show/hide the scroll-to-top button when scrolling
    $(window).scroll(function() {
        if ($(window).scrollTop() > 100) {
            btn.fadeIn();
        } else {
            btn.fadeOut();
        }
    });

    // Scroll to top action when button is clicked
    btn.on('click', function(e) {
        e.preventDefault();
        $('html, body').animate({ scrollTop: 0 }, '300');
    });
});
