<?php
/**
 * Plugin Name:       Simple Scroll to Top WP
 * Plugin URI:        https://www.wordpress.com/plugins/simple-scroll-on-top-wp
 * Description:       Simple Scroll to Top plugin adds a "Back to Top" button to your WordPress website along with social share buttons.
 * Version:           1.0.0
 * Requires at least: 5.2
 * Requires PHP:      7.2
 * Author:            Mahmudul Hasan Sheepu
 * Author URI:        https://mhsheepu.netlify.app/
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       sstt
 */

// Enqueue styles and scripts
function sstt_enqueue_scripts() {
    wp_enqueue_script('jquery');  // Ensure jQuery is loaded
    wp_enqueue_style('sstt-font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css');
    wp_enqueue_style('sstt-style', plugin_dir_url(__FILE__) . 'assets/css/simple-scroll-top.css');
    wp_enqueue_script('sstt-script', plugin_dir_url(__FILE__) . 'assets/js/simple-scroll-top.js', array('jquery'), null, true);
}
add_action('wp_enqueue_scripts', 'sstt_enqueue_scripts');

// Add Scroll to Top Button and Social Share Buttons to the footer
function sstt_add_buttons() {
    echo '<div id="sstt-scroll-top"><i class="fas fa-arrow-up"></i></div>';
    echo '<div id="sstt-floating-share">
            <a href="https://facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
            <a href="https://twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
            <a href="https://linkedin.com" target="_blank"><i class="fab fa-linkedin-in"></i></a>
           
          </div>';
}
add_action('wp_footer', 'sstt_add_buttons');
?>
